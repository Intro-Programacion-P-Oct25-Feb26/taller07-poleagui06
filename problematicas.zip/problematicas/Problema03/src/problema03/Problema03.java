/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package problema03;

/**
 *
 * @author Pole
 */
public class Problema03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int contador = 1;
        int resultado = 2;
        int secuencia = 3;
        String mensaje = "";
        System.out.println("2");
        
     while (contador <= 5){
         
        resultado = resultado + secuencia;
        secuencia = secuencia + 2 ;
        contador = contador + 1;     
        
        mensaje = String.format("%s%d\n", mensaje, resultado);
     
     }
        System.out.printf("%s",mensaje);
        // TODO code application logic here
    }
    
}
